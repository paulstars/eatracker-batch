# Installation

Legen Sie den Batch-Ordner im selben Ordner ab, in dem auch das eatracker Repos liegt.

# Install npm

Run installFront --> öffnet eine neue CMD für jedes install

Warten Sie jede Installation ab, schließen Sie dessen CMD und drücken Sie In der ersten CMD Enter.
