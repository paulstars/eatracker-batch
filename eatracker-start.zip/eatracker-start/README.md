# Installation

Laden Sie sich die eatracker-start.zip herunter und entpacken diese im selben Ordner, in dem auch Ihr eatracker Repos liegt.

# Ausführen

startBack startest das Backend.
startFront startet das Frontend.
installNPM installiert alle benötigten Module.

# Install NPM

Run installFront --> öffnet eine neue CMD für jedes install

Warten Sie jede Installation ab, schließen Sie dessen CMD und drücken Sie In der ersten CMD Enter.
